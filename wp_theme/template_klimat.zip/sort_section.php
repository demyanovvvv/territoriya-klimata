<div class="row">
    <div class="col-xl-12 mt-5">
        <h3>Сортировка товара</h3>
        <div class="card border-0 mt-3">
            <div class="card-body">
                <div class="row">
                    <div class="col-xl-9">
                        <form class="form-sort mt-3">
                            <div class="form-row">
                                <div class="col-xl-12">
                                    <label class="mr-sm-2 form-sort__par" for="inlineFormCustomSelect">Мощность</label>
                                    <span class="form-sort__start">от</span>
                                    <select class="custom-select mb-2 mr-xl-2 mb-xl-0 form-sort__select" id="inlineFormCustomSelect">
                                          <option selected>0 кВт</option>
                                          <option value="1">3.3 кВт</option>
                                          <option value="2">4.2 кВт</option>
                                          <option value="3">5.2 кВт</option>
                                    </select>
                                    <span class="form-sort__end">до</span>
                                    <select class="custom-select mb-2 mr-xl-2 mb-xl-0 form-sort__select" id="inlineFormCustomSelect">
                                            <option selected>0 кВт</option>
                                            <option value="1">5.8 кВт</option>
                                            <option value="2">6.3 кВт</option>
                                            <option value="3">6.7 кВт</option>
                                    </select>
                                </div>
                                <div class="col-xl-12 mt-5">
                                        <label class="mr-sm-2 form-sort__par" for="inlineFormCustomSelect">Стоимость</label>
                                        <span class="form-sort__start">от</span>
                                        <select class="custom-select mb-2 mr-xl-2 mb-xl-0 form-sort__select" id="inlineFormCustomSelect">
                                              <option selected>0 руб.</option>
                                              <option value="1">9 500 руб.</option>
                                              <option value="2">11 200 руб.</option>
                                              <option value="3">15 100 руб.</option>
                                        </select>
                                        <span class="form-sort__end">до</span>
                                        <select class="custom-select mb-2 mr-xl-2 mb-xl-0 form-sort__select" id="inlineFormCustomSelect">
                                                <option selected>0 руб.</option>
                                                <option value="1">12 200 руб.</option>
                                                <option value="2">15 600 руб.</option>
                                                <option value="3">17 000 руб.</option>
                                        </select>
                                    </div>
                            </div>
                        </form>
                    </div>
                    <div class="col-xl-3 form-sort__hr-left">
                        <button type="button" class="btn btn-primary btn-lg form-sort__button-sort">Поиск</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>