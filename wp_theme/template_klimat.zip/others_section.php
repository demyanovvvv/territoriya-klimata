
        
        <div class="row mt-5 other-section">
    <div class="col-xl-6">
        <h3 class="other-section__header-promo">Акции</h3>
        <div class="row">
            <div class="col-xl-12 mt-3">
                <div class="row">
                    <div class="col-xl-6">
                        <div class="card border-0 cat-card">
                            <div class="card-body cat-product">
                                <div class="px-3 cat-product__inner">
    <a class="cat-product-link" href="#">
        <img class="img-fluid img-thumbnail cat-product__img" src="images/img_product_cat.png" alt="">
        <div class="cat-product__inner-link">
            <div class="cat-product__link">Сплит-система (инвертор) Samsung AR09KSFPAWQNER</div>
        </div>
    </a>
    <div class="mt-1 cat-product__reviews">
        <img class="cat-product__reviews-stars" src="images/stars.svg" alt=""> <span class="badge badge-light cat-product__reviews-num">(10)</span> <span class="badge badge-light cat-product__reviews-link">(<a href="#">отзывы</a>)</span>
    </div>
    <div class="row">
        <a class="cat-product__price-link" href="#">
            <div class="col-xl-8 cat-product__price">
                35990 руб.
                <span>Подробнее</span>
            </div>
        </a>
        <div class="col-xl-4 cat-product__button">
            <a class="btn btn-primary btn-sm cat-product__button-call" href="#" role="button">
                <span class="cat-product__button-call-icon"></span>
                заказать
            </a>
        </div>
    </div>
</div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-6">
                        <div class="card border-0 cat-card">
                            <div class="card-body cat-product">
                                <div class="px-3 cat-product__inner">
    <a class="cat-product-link" href="#">
        <img class="img-fluid img-thumbnail cat-product__img" src="images/img_product_cat.png" alt="">
        <div class="cat-product__inner-link">
            <div class="cat-product__link">Сплит-система (инвертор) Samsung AR09KSFPAWQNER</div>
        </div>
    </a>
    <div class="mt-1 cat-product__reviews">
        <img class="cat-product__reviews-stars" src="images/stars.svg" alt=""> <span class="badge badge-light cat-product__reviews-num">(10)</span> <span class="badge badge-light cat-product__reviews-link">(<a href="#">отзывы</a>)</span>
    </div>
    <div class="row">
        <a class="cat-product__price-link" href="#">
            <div class="col-xl-8 cat-product__price">
                35990 руб.
                <span>Подробнее</span>
            </div>
        </a>
        <div class="col-xl-4 cat-product__button">
            <a class="btn btn-primary btn-sm cat-product__button-call" href="#" role="button">
                <span class="cat-product__button-call-icon"></span>
                заказать
            </a>
        </div>
    </div>
</div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-6 mt-4">
                        <div class="card border-0 cat-card">
                            <div class="card-body cat-product">
                                <div class="px-3 cat-product__inner">
    <a class="cat-product-link" href="#">
        <img class="img-fluid img-thumbnail cat-product__img" src="images/img_product_cat.png" alt="">
        <div class="cat-product__inner-link">
            <div class="cat-product__link">Сплит-система (инвертор) Samsung AR09KSFPAWQNER</div>
        </div>
    </a>
    <div class="mt-1 cat-product__reviews">
        <img class="cat-product__reviews-stars" src="images/stars.svg" alt=""> <span class="badge badge-light cat-product__reviews-num">(10)</span> <span class="badge badge-light cat-product__reviews-link">(<a href="#">отзывы</a>)</span>
    </div>
    <div class="row">
        <a class="cat-product__price-link" href="#">
            <div class="col-xl-8 cat-product__price">
                35990 руб.
                <span>Подробнее</span>
            </div>
        </a>
        <div class="col-xl-4 cat-product__button">
            <a class="btn btn-primary btn-sm cat-product__button-call" href="#" role="button">
                <span class="cat-product__button-call-icon"></span>
                заказать
            </a>
        </div>
    </div>
</div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-6 mt-4">
                        <div class="card border-0 cat-card">
                            <div class="card-body cat-product">
                                <div class="px-3 cat-product__inner">
    <a class="cat-product-link" href="#">
        <img class="img-fluid img-thumbnail cat-product__img" src="images/img_product_cat.png" alt="">
        <div class="cat-product__inner-link">
            <div class="cat-product__link">Сплит-система (инвертор) Samsung AR09KSFPAWQNER</div>
        </div>
    </a>
    <div class="mt-1 cat-product__reviews">
        <img class="cat-product__reviews-stars" src="images/stars.svg" alt=""> <span class="badge badge-light cat-product__reviews-num">(10)</span> <span class="badge badge-light cat-product__reviews-link">(<a href="#">отзывы</a>)</span>
    </div>
    <div class="row">
        <a class="cat-product__price-link" href="#">
            <div class="col-xl-8 cat-product__price">
                35990 руб.
                <span>Подробнее</span>
            </div>
        </a>
        <div class="col-xl-4 cat-product__button">
            <a class="btn btn-primary btn-sm cat-product__button-call" href="#" role="button">
                <span class="cat-product__button-call-icon"></span>
                заказать
            </a>
        </div>
    </div>
</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="col-xl-6">
            <h3 class="other-section__header-bestsellers">Хиты продаж</h3>
            <div class="row">
                <div class="col-xl-12 mt-3">
                    <div class="row">
                        <div class="col-xl-6">
                            <div class="card border-0 cat-card">
                                <div class="card-body cat-product">
                                    <div class="px-3 cat-product__inner">
    <a class="cat-product-link" href="#">
        <img class="img-fluid img-thumbnail cat-product__img" src="images/img_product_cat.png" alt="">
        <div class="cat-product__inner-link">
            <div class="cat-product__link">Сплит-система (инвертор) Samsung AR09KSFPAWQNER</div>
        </div>
    </a>
    <div class="mt-1 cat-product__reviews">
        <img class="cat-product__reviews-stars" src="images/stars.svg" alt=""> <span class="badge badge-light cat-product__reviews-num">(10)</span> <span class="badge badge-light cat-product__reviews-link">(<a href="#">отзывы</a>)</span>
    </div>
    <div class="row">
        <a class="cat-product__price-link" href="#">
            <div class="col-xl-8 cat-product__price">
                35990 руб.
                <span>Подробнее</span>
            </div>
        </a>
        <div class="col-xl-4 cat-product__button">
            <a class="btn btn-primary btn-sm cat-product__button-call" href="#" role="button">
                <span class="cat-product__button-call-icon"></span>
                заказать
            </a>
        </div>
    </div>
</div>
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-6">
                            <div class="card border-0 cat-card">
                                <div class="card-body cat-product">
                                    <div class="px-3 cat-product__inner">
    <a class="cat-product-link" href="#">
        <img class="img-fluid img-thumbnail cat-product__img" src="images/img_product_cat.png" alt="">
        <div class="cat-product__inner-link">
            <div class="cat-product__link">Сплит-система (инвертор) Samsung AR09KSFPAWQNER</div>
        </div>
    </a>
    <div class="mt-1 cat-product__reviews">
        <img class="cat-product__reviews-stars" src="images/stars.svg" alt=""> <span class="badge badge-light cat-product__reviews-num">(10)</span> <span class="badge badge-light cat-product__reviews-link">(<a href="#">отзывы</a>)</span>
    </div>
    <div class="row">
        <a class="cat-product__price-link" href="#">
            <div class="col-xl-8 cat-product__price">
                35990 руб.
                <span>Подробнее</span>
            </div>
        </a>
        <div class="col-xl-4 cat-product__button">
            <a class="btn btn-primary btn-sm cat-product__button-call" href="#" role="button">
                <span class="cat-product__button-call-icon"></span>
                заказать
            </a>
        </div>
    </div>
</div>
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-6 mt-4">
                            <div class="card border-0 cat-card">
                                <div class="card-body cat-product">
                                    <div class="px-3 cat-product__inner">
    <a class="cat-product-link" href="#">
        <img class="img-fluid img-thumbnail cat-product__img" src="images/img_product_cat.png" alt="">
        <div class="cat-product__inner-link">
            <div class="cat-product__link">Сплит-система (инвертор) Samsung AR09KSFPAWQNER</div>
        </div>
    </a>
    <div class="mt-1 cat-product__reviews">
        <img class="cat-product__reviews-stars" src="images/stars.svg" alt=""> <span class="badge badge-light cat-product__reviews-num">(10)</span> <span class="badge badge-light cat-product__reviews-link">(<a href="#">отзывы</a>)</span>
    </div>
    <div class="row">
        <a class="cat-product__price-link" href="#">
            <div class="col-xl-8 cat-product__price">
                35990 руб.
                <span>Подробнее</span>
            </div>
        </a>
        <div class="col-xl-4 cat-product__button">
            <a class="btn btn-primary btn-sm cat-product__button-call" href="#" role="button">
                <span class="cat-product__button-call-icon"></span>
                заказать
            </a>
        </div>
    </div>
</div>
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-6 mt-4">
                            <div class="card border-0 cat-card">
                                <div class="card-body cat-product">
                                    <div class="px-3 cat-product__inner">
    <a class="cat-product-link" href="#">
        <img class="img-fluid img-thumbnail cat-product__img" src="images/img_product_cat.png" alt="">
        <div class="cat-product__inner-link">
            <div class="cat-product__link">Сплит-система (инвертор) Samsung AR09KSFPAWQNER</div>
        </div>
    </a>
    <div class="mt-1 cat-product__reviews">
        <img class="cat-product__reviews-stars" src="images/stars.svg" alt=""> <span class="badge badge-light cat-product__reviews-num">(10)</span> <span class="badge badge-light cat-product__reviews-link">(<a href="#">отзывы</a>)</span>
    </div>
    <div class="row">
        <a class="cat-product__price-link" href="#">
            <div class="col-xl-8 cat-product__price">
                35990 руб.
                <span>Подробнее</span>
            </div>
        </a>
        <div class="col-xl-4 cat-product__button">
            <a class="btn btn-primary btn-sm cat-product__button-call" href="#" role="button">
                <span class="cat-product__button-call-icon"></span>
                заказать
            </a>
        </div>
    </div>
</div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
</div>